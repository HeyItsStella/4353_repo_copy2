# 4353_Group_project
This is a fuel rate calculating project
By Stella, Jack, and Evan in Group 8